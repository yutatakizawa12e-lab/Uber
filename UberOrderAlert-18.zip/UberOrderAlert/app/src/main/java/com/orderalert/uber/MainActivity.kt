package com.orderalert.uber

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var editBotToken: EditText
    private lateinit var editChatId: EditText
    private lateinit var editRateThreshold: EditText
    private lateinit var editFoodcourtKeywords: EditText
    private lateinit var editTroubleKeywords: EditText
    private lateinit var txtStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editBotToken = findViewById(R.id.editBotToken)
        editChatId = findViewById(R.id.editChatId)
        editRateThreshold = findViewById(R.id.editRateThreshold)
        editFoodcourtKeywords = findViewById(R.id.editFoodcourtKeywords)
        editTroubleKeywords = findViewById(R.id.editTroubleKeywords)
        txtStatus = findViewById(R.id.txtStatus)

        val prefs = getSharedPreferences(SettingsStore.PREFS_NAME, Context.MODE_PRIVATE)
        editBotToken.setText(prefs.getString(SettingsStore.KEY_BOT_TOKEN, ""))
        editChatId.setText(prefs.getString(SettingsStore.KEY_CHAT_ID, ""))
        editRateThreshold.setText(
            prefs.getFloat(SettingsStore.KEY_RATE_THRESHOLD, SettingsStore.DEFAULT_RATE_THRESHOLD.toFloat()).toString()
        )
        editFoodcourtKeywords.setText(prefs.getString(SettingsStore.KEY_FOODCOURT_KEYWORDS, ""))
        editTroubleKeywords.setText(prefs.getString(SettingsStore.KEY_TROUBLE_KEYWORDS, ""))

        findViewById<Button>(R.id.btnSave).setOnClickListener {
            val threshold = editRateThreshold.text.toString().trim().toFloatOrNull()
                ?: SettingsStore.DEFAULT_RATE_THRESHOLD.toFloat()
            prefs.edit()
                .putString(SettingsStore.KEY_BOT_TOKEN, editBotToken.text.toString().trim())
                .putString(SettingsStore.KEY_CHAT_ID, editChatId.text.toString().trim())
                .putFloat(SettingsStore.KEY_RATE_THRESHOLD, threshold)
                .putString(SettingsStore.KEY_FOODCOURT_KEYWORDS, editFoodcourtKeywords.text.toString().trim())
                .putString(SettingsStore.KEY_TROUBLE_KEYWORDS, editTroubleKeywords.text.toString().trim())
                .apply()
            Toast.makeText(this, "保存しました", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.btnOpenSettings).setOnClickListener {
            // Android設定の「通知アクセス」画面を開く。ここでこのアプリを有効にする必要がある。
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        }

        findViewById<Button>(R.id.btnTest).setOnClickListener {
            val token = editBotToken.text.toString().trim()
            val chatId = editChatId.text.toString().trim()
            if (token.isBlank() || chatId.isBlank()) {
                Toast.makeText(this, "先にBot TokenとChat IDを入力してください", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            sendTestMessage(token, chatId)
        }
    }

    private fun sendTestMessage(token: String, chatId: String) {
        thread {
            try {
                val text = URLEncoder.encode("✅ テスト通知: この設定は正常に動作しています", "UTF-8")
                val url = URL("https://api.telegram.org/bot$token/sendMessage?chat_id=$chatId&text=$text")
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "GET"
                val code = conn.responseCode
                conn.disconnect()
                runOnUiThread {
                    txtStatus.text = if (code == 200) "送信成功" else "送信失敗 (コード: $code)"
                }
            } catch (e: Exception) {
                runOnUiThread { txtStatus.text = "エラー: ${e.message}" }
            }
        }
    }
}
