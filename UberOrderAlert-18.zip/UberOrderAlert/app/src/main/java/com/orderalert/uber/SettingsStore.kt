package com.orderalert.uber

object SettingsStore {
    const val PREFS_NAME = "order_alert_prefs"
    const val KEY_BOT_TOKEN = "bot_token"
    const val KEY_CHAT_ID = "chat_id"

    // カンマ区切りでキーワードを保存する
    const val KEY_FOODCOURT_KEYWORDS = "foodcourt_keywords"   // 例: フードコート,駅ビル,〇〇モール
    const val KEY_TROUBLE_KEYWORDS = "trouble_keywords"       // 例: 〇〇食堂,△△タワー(駐輪場遠い)

    // 円/kmの警告しきい値(これを下回ったら注意表示)
    const val KEY_RATE_THRESHOLD = "rate_threshold"
    const val DEFAULT_RATE_THRESHOLD = 150.0
}
