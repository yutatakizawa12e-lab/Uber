package com.orderalert.uber

import android.app.Notification
import android.content.Context
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.concurrent.thread

/**
 * Uber Driverアプリ(パッケージ名: com.ubercab.driver)からの通知を検知し、
 * Telegram Bot経由でスマホ/PCに転送するサービス。
 *
 * 設定(Botトークン・チャットID)はMainActivityで保存したSharedPreferencesを使う。
 */
class OrderNotificationListener : NotificationListenerService() {

    companion object {
        private const val TAG = "OrderNotificationListener"

        // 監視対象のパッケージ名(Uber Driverアプリ)
        private val TARGET_PACKAGES = setOf(
            "com.ubercab.driver",
            "com.ubercab.eats.driver" // 一部地域/バージョンで異なる場合の予備
        )
    }

    // 金額: ¥979 / ￥1,234 / 979円 などに対応
    private val amountRegex = Regex("""[¥￥]\s*([0-9][0-9,]*)|([0-9][0-9,]*)\s*円""")
    // 距離: 5.8 km / 5.8km に対応
    private val distanceRegex = Regex("""([0-9]+(?:\.[0-9]+)?)\s*km""", RegexOption.IGNORE_CASE)

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        super.onNotificationPosted(sbn)

        if (sbn.packageName !in TARGET_PACKAGES) return

        val extras = sbn.notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: "新しい注文"
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        val subText = extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString() ?: ""
        val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString() ?: ""
        val combined = listOf(title, text, subText, bigText).joinToString(" ")

        Log.d(TAG, "Uber通知を検知: $combined")

        val prefs = getSharedPreferences(SettingsStore.PREFS_NAME, Context.MODE_PRIVATE)
        val botToken = prefs.getString(SettingsStore.KEY_BOT_TOKEN, null)
        val chatId = prefs.getString(SettingsStore.KEY_CHAT_ID, null)

        if (botToken.isNullOrBlank() || chatId.isNullOrBlank()) {
            Log.w(TAG, "Bot設定が未入力のため転送をスキップしました")
            return
        }

        val message = buildMessage(prefs, title, text, combined)
        sendTelegramMessage(botToken, chatId, message)
    }

    private fun buildMessage(
        prefs: android.content.SharedPreferences,
        title: String,
        text: String,
        combined: String
    ): String {
        val sb = StringBuilder()
        sb.append("🔔 Uber注文が入りました\n$title\n$text\n")

        // --- 金額・距離を抽出してキロ単価を計算 ---
        val amountMatch = amountRegex.find(combined)
        val distanceMatch = distanceRegex.find(combined)

        val amount = amountMatch?.let {
            (it.groupValues[1].ifBlank { it.groupValues[2] }).replace(",", "").toDoubleOrNull()
        }
        val distance = distanceMatch?.groupValues?.get(1)?.toDoubleOrNull()

        if (amount != null && distance != null && distance > 0) {
            val rate = amount / distance
            val threshold = prefs.getFloat(
                SettingsStore.KEY_RATE_THRESHOLD,
                SettingsStore.DEFAULT_RATE_THRESHOLD.toFloat()
            ).toDouble()
            sb.append("\n💰 ¥%.0f / %.1fkm → 単価 %.0f円/km".format(amount, distance, rate))
            if (rate < threshold) {
                sb.append("\n⚠️ 単価が低めです(しきい値 %.0f円/km未満)".format(threshold))
            }
        } else {
            sb.append("\n(金額・距離を通知文から読み取れませんでした)")
        }

        // --- フードコート/駅ビル判定 ---
        val foodcourtKeywords = prefs.getString(SettingsStore.KEY_FOODCOURT_KEYWORDS, "")
            ?.split(",")?.map { it.trim() }?.filter { it.isNotEmpty() } ?: emptyList()
        val matchedFoodcourt = foodcourtKeywords.firstOrNull { combined.contains(it) }
        if (matchedFoodcourt != null) {
            sb.append("\n🍽 フードコート/駅ビル系: 「$matchedFoodcourt」に一致")
        }

        // --- 厄介な店の判定 ---
        val troubleKeywords = prefs.getString(SettingsStore.KEY_TROUBLE_KEYWORDS, "")
            ?.split(",")?.map { it.trim() }?.filter { it.isNotEmpty() } ?: emptyList()
        val matchedTrouble = troubleKeywords.firstOrNull { combined.contains(it) }
        if (matchedTrouble != null) {
            sb.append("\n🚨 要注意店にヒット: 「$matchedTrouble」")
        }

        return sb.toString()
    }

    /** Telegram Bot APIにメッセージを送信する(バックグラウンドスレッドで実行) */
    private fun sendTelegramMessage(botToken: String, chatId: String, message: String) {
        thread {
            try {
                val encodedText = URLEncoder.encode(message, "UTF-8")
                val urlStr = "https://api.telegram.org/bot$botToken/sendMessage" +
                        "?chat_id=$chatId&text=$encodedText"
                val url = URL(urlStr)
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "GET"
                conn.connectTimeout = 10000
                conn.readTimeout = 10000
                val code = conn.responseCode
                Log.d(TAG, "Telegram送信結果コード: $code")
                conn.disconnect()
            } catch (e: Exception) {
                Log.e(TAG, "Telegram送信に失敗しました", e)
            }
        }
    }
}
